# Road Ready Drives — Frontend

This is a multi-page static frontend for the Road Ready Drives website.

## Included pages
- index.html (Home)
- about.html (About)
- services.html (Services & Pricing)
- gallery.html (Gallery)
- booking.html (Booking form)
- contact.html (Contact + map)

## How to deploy on GitHub Pages
1. Create a new GitHub repository (e.g. `road-ready-frontend`)
2. Upload all files from this zip to the **root** of the repo
3. In repository **Settings → Pages**, set:
   - Branch: `main`
   - Folder: `/ (root)`
4. Save and wait ~1 minute. Your site will be at:
   `https://<your-username>.github.io/<repo-name>/`

## Backend connection
The booking form POSTs to `https://your-backend-url.example.com/api/book`.
Replace `BACKEND_URL` in `script.js` with your actual backend URL (Render).

