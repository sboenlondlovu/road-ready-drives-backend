// script.js basic interactivity and booking form POST
document.addEventListener('DOMContentLoaded', function(){
  // carousel
  const slides = document.querySelectorAll('.carousel .slide');
  let idx = 0;
  if(slides.length>1){
    setInterval(()=> {
      slides[idx].classList.remove('active');
      idx = (idx+1)%slides.length;
      slides[idx].classList.add('active');
    },4000);
  }

  // booking form
  const bookingForm = document.getElementById('bookingForm');
  if(bookingForm){
    bookingForm.addEventListener('submit', async function(e){
      e.preventDefault();
      const data = Object.fromEntries(new FormData(bookingForm).entries());
      const msgEl = document.getElementById('bookingMsg');
      msgEl.textContent = 'Sending...';
      try{
        // Replace BACKEND_URL with your real backend URL once deployed
        const BACKEND_URL = 'https://your-backend-url.example.com';
        const res = await fetch(BACKEND_URL + '/api/book', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify(data)
        });
        if(res.ok){
          msgEl.textContent = 'Booking sent — we will contact you soon.';
          bookingForm.reset();
        } else {
          msgEl.textContent = 'Failed to send. Please call 068 388 9258.';
        }
      }catch(err){
        msgEl.textContent = 'Network error — please try later or call 068 388 9258.';
      }
    });
  }
});
